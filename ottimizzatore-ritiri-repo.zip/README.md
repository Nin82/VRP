# Ottimizzatore Ritiri

Webapp per pianificare i ritiri giornalieri su una flotta di mezzi:
carica un file Excel/CSV con i ritiri, l'app li geolocalizza, li incastra
sul minor numero di mezzi possibile rispettando **capacità** (in m³, via
bancali) e **finestre orarie**, e disegna i percorsi ottimizzati su mappa.

Nessuna API a pagamento: OpenStreetMap (mappa e geocoding via Nominatim)
e OSRM (calcolo distanze/percorsi).

## Struttura del progetto

```
index.html        struttura della pagina (nessuno stile o script inline)
css/style.css      tutti gli stili
js/app.js          logica dell'app (un unico file per ora — vedi sotto)
config.json        costanti/parametri di default, endpoint, sinonimi colonne file
.devcontainer/      configurazione per aprire il progetto in GitHub Codespaces
package.json        script "start" per un server locale
```

**Perché config.json e non hardcoded in app.js:** i parametri che cambiano
spesso (capacità mezzo, tolleranze, endpoint) sono dati, non logica — separarli
permette di modificarli senza toccare il codice.

**Nota importante:** l'app usa `fetch('./config.json')` e moduli ES
(`<script type="module">`), quindi **va servita via http**, non aperta con
doppio click dal filesystem (altrimenti il browser blocca il fetch per CORS).
Su Codespaces questo è già gestito automaticamente (vedi sotto).

## Piano di modularizzazione

Per ora tutta la logica sta in `js/app.js`, organizzata in sezioni commentate
(CONFIG, STATO, MAPPA, IMPORT FILE, GEOCODING, VRPTW, OSRM, RENDERING,
OTTIMIZZAZIONE, EVENTI UI). Le prossime feature andranno in file separati,
ad esempio:

- `js/geocoding.js` — ricerca indirizzi e verifica città
- `js/vrptw.js` — costruzione e raffinamento dei giri
- `js/fileImport.js` — parsing Excel/CSV
- `js/ui.js` — rendering e gestione eventi

Quando un file diventa abbastanza stabile lo estraiamo da `app.js` con un
`import`/`export` (già pronto, essendo un modulo ES).

## Avvio locale

```bash
npm start
```

Apre un server statico su `http://localhost:5500`.

## Avvio su GitHub Codespaces

1. Crea il repo su GitHub con questi file.
2. "Code" → "Codespaces" → "Create codespace on main".
3. Il devcontainer avvia automaticamente un server sulla porta 5500 e apre
   l'anteprima. Se non si apre da sola: tab "Ports" → apri la porta 5500.

## Stato attuale / cosa fa già

- Import massivo da Excel/CSV (colonne: Cliente, Indirizzo, CAP, Località,
  Orario ritiro, Bancali o Metri cubi — riconoscimento colonne tollerante).
- Geocoding con verifica incrociata della città (evita di accettare un
  indirizzo omonimo nella città sbagliata) e fallback a più livelli
  (via+CAP+città → via+città → solo CAP → solo città).
- Costruzione dei giri con un'euristica VRPTW (capacitated insertion):
  minimizza i mezzi usati sul totale disponibile, rispettando capacità
  (m³) e finestre orarie: due ritiri vengono abbinati sullo stesso mezzo
  solo se geograficamente e temporalmente compatibili.
- Raffinamento 2-opt vincolato (riduce i km senza rompere gli orari).
- Segnalazione esplicita di: ritiri non geolocalizzabili, città sospette,
  ritiri non assegnabili (capacità/orari incompatibili con la flotta
  disponibile), giri che superano la durata massima impostata.

## Prossimi passi previsti

- Estrazione dei moduli elencati sopra in file separati.
- Gestione di più giri per lo stesso mezzo nella stessa giornata.
- Persistenza su file/DB condiviso invece che solo locale al browser.
